#if defined(__has_include)
# if __has_include(<Google/AppInvite.h>)
#  include <Google/AppInvite.h>
# endif
#endif
